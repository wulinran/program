public class Exe02{
	public static void main(String[] args){
	char a='a';
	char b='Ů';
		System.out.println("a:"+ a +"\nb:"+b);
	}

}