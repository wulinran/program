public class Exe03{
	public static void main(String[] args){
		int a=123;
		double b=456;
		float c=678;
		double m=(a-b)*(a+c);
		double n=(a+b)/(b-c);
			System.out.println("m:"+ m +"\nn:"+n);
	
	}


}