public class Exe01{
	public static void main(String[] args){
		boolean a=true;
		boolean b=false;
		//boolean c=0; boolean��ֵֻ����true��false
			System.out.println(a);
			System.out.println(b);

			//System.out.println(c);
	
	}

}