public interface  Assaultable{

	public abstract void attack();
}