class WarShip extends Weapon{
	public  void attack(){
		System.out.println("WarShip����");
	}
	public  void move(){
		System.out.println("WarShip�ƶ�");
	}
}