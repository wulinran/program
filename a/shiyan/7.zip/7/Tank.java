class Tank extends Weapon{
	public  void attack(){
		System.out.println("Tank����");
	}
	public  void move(){
		System.out.println("Tank�ƶ�");
	}
}