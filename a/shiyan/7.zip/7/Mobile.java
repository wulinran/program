public interface  Mobile{

	public abstract void move();
}
