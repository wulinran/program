class Flighter extends Weapon{
	public  void attack(){
		System.out.println("Flighter����");
	}
	public  void move(){
		System.out.println("Flighter�ƶ�");
	}
}